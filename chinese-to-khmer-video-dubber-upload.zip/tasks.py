import os, subprocess
from pathlib import Path
from celery import Celery
from openai import OpenAI
REDIS_URL=os.getenv("REDIS_URL","redis://localhost:6379/0")
celery_app=Celery("dubber",broker=REDIS_URL,backend=REDIS_URL)
@celery_app.task
def process_video(job_id,src):
    out=Path("outputs"); out.mkdir(exist_ok=True)
    wav=out/(job_id+".wav"); transcript=out/(job_id+".txt")
    subprocess.run(["ffmpeg","-y","-i",src,"-vn","-ac","1","-ar","16000",str(wav)],check=True)
    client=OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    with wav.open("rb") as f:
        r=client.audio.transcriptions.create(model="gpt-4o-transcribe",file=f)
    transcript.write_text(getattr(r,"text",""),encoding="utf-8")
    return {"job_id":job_id,"status":"transcribed","transcript":str(transcript)}
