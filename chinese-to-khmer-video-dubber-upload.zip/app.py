import uuid
from pathlib import Path
from fastapi import FastAPI, UploadFile, File
from tasks import process_video
app=FastAPI(title="Chinese to Khmer Video Dubber")
Path("uploads").mkdir(exist_ok=True)
@app.get("/health")
def health(): return {"ok":True}
@app.post("/jobs")
async def jobs(video: UploadFile=File(...)):
    job_id=str(uuid.uuid4()); p=Path("uploads")/(job_id+Path(video.filename or ".mp4").suffix)
    with p.open("wb") as f:
        while chunk:=await video.read(1024*1024): f.write(chunk)
    t=process_video.delay(job_id,str(p))
    return {"job_id":job_id,"task_id":t.id,"status":"queued"}
