# Chinese → Khmer Video Dubber

FastAPI + Celery + Redis + FFmpeg starter for Chinese-to-Khmer video processing.
